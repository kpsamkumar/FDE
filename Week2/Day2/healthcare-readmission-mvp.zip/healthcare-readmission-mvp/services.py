
import repository
from http.client import HTTPException
from select import select
from tkinter import INSERT
from fastapi import HTTPException
from database import get_database_connection


def get_encounters():
    return repository.get_encounters()

def get_encounter_by_id(encounter_id):
    return repository.get_encounter_by_id(encounter_id) 


def care_queue():   
    return repository.care_queue()  


def care_queue_by_risk_level(risk_level):
    return repository.care_queue_by_risk_level(risk_level)


def update_interventions(encounter_id, interventions):
    return repository.update_interventions(encounter_id, interventions)



def get_operations_summary():
    return repository.get_operations_summary()  
    

def calculate_risk_score(number_inpatient, number_emergency, number_outpatient,time_in_hospital, num_medications):
    """
    Calculate the risk score based on the provided parameters.

    Args:
        number_inpatient (int): Number of inpatient visits.
        number_emergency (int): Number of emergency visits.
        number_outpatient (int): Number of outpatient visits.
        time_in_hospital (int): Time spent in the hospital.
        num_medications (int): Number of medications.

    Returns:
        int: The calculated risk score.
    """
    # Example risk score calculation logic
    risk_score =0
    if number_inpatient >= 3:
        risk_score += 3

    if number_emergency >= 2:
        risk_score += 2

    if number_outpatient >= 3:
        risk_score += 1

    if num_medications >= 20:
        risk_score += 1

    if time_in_hospital >= 7:
        risk_score += 1

    return risk_score

def calculate_risk_level(risk_score):
    """
    Calculate the risk level based on the provided risk score.

    Args:
        risk_score (int): The calculated risk score.

    Returns:
        str: The calculated risk level.
    """
    if risk_score >= 5:
        return "HIGH"
    elif risk_score >= 4:
        return "MEDIUM"
    else:
        return "LOW"