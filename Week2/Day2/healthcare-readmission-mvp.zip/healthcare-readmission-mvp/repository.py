
from http.client import HTTPException
from select import select
from tkinter import INSERT
from fastapi import HTTPException
from database import get_database_connection

def get_encounters():
    """
    Fetch all patient encounters from the database.

    Returns:
        list: A list of dictionaries representing patient encounters.
    """
    try:
        from database import get_database_connection
        with get_database_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM patient_encounters;")
                rows = cur.fetchall()
                columns = [desc[0] for desc in cur.description]
                encounters = [dict(zip(columns, row)) for row in rows]
                return encounters
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def get_encounter_by_id(encounter_id):
    """
    Fetch a specific patient encounter by its ID.

    Args:
        encounter_id (int): The ID of the patient encounter.

    Returns:
        dict: A dictionary representing the patient encounter.
    """
    try:
        from database import get_database_connection
        with get_database_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM patient_encounters WHERE encounter_id = %s;", (encounter_id,))
                row = cur.fetchone()
                if row is None:
                    raise ValueError(f"Encounter with ID {encounter_id} not found.")
                columns = [desc[0] for desc in cur.description]
                encounter = dict(zip(columns, row))
                return encounter
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def care_queue():
    """
    Fetch the care queue from the database.

    Returns:
        list: A list of dictionaries representing the care queue.
    """
    try:
        from database import get_database_connection
        with get_database_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM patient_encounters where  risk_level IN ('HIGH', 'MEDIUM');")
                rows = cur.fetchall()
                columns = [desc[0] for desc in cur.description]
                care_queue = [dict(zip(columns, row)) for row in rows]
                return care_queue
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def care_queue_by_risk_level(risk_level):
    """
    Fetch the care queue filtered by risk level from the database.

    Args:
        risk_level (str): The risk level to filter by (e.g., 'High', 'Medium', 'Low').  

    Returns:
        list: A list of dictionaries representing the care queue filtered by risk level.
    """
    try:
        from database import get_database_connection
        with get_database_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM patient_encounters WHERE risk_level = %s;", (risk_level.upper(),))
                rows = cur.fetchall()
                columns = [desc[0] for desc in cur.description]
                care_queue = [dict(zip(columns, row)) for row in rows]
                return care_queue
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def update_interventions(encounter_id, interventions):
    """
    Update the interventions for a specific patient encounter.

    Args:
        encounter_id(int): The ID of the patient encounter.
        interventions (dict): A dictionary containing the updated intervention details.
    """
    try:
        from database import get_database_connection
        with get_database_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT count(*) FROM care_interventions WHERE encounter_id = %s;", (encounter_id,))
                interventions_count = cur.fetchone()[0]
                print(f"Interventions count for encounter_id {encounter_id}: {interventions_count}")
                if interventions_count == 0:
                    cur.execute("INSERT INTO care_interventions (encounter_id, status, assigned_to, notes) VALUES (%s, %s, %s, %s);", (encounter_id, interventions.get("status"), interventions.get("assigned_to"), interventions.get("notes")))
                    print(f"Inserted new interventions for encounter_id {encounter_id}")
                else:       
                    cur.execute("UPDATE care_interventions SET status = %s, assigned_to = %s, notes = %s, updated_at = CURRENT_TIMESTAMP WHERE encounter_id = %s;", (interventions.get("status"), interventions.get("assigned_to"), interventions.get("notes"), encounter_id))
                conn.commit()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))     
def get_operations_summary():
    """
    Fetch the operations summary from the database.

    Returns:
        dict: A dictionary containing the operations summary.
    """
    try:
        from database import get_database_connection

        with get_database_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    WITH ci AS (
                        SELECT
                            encounter_id,
                            bool_or(status = 'PENDING_REVIEW') AS is_pending,
                            bool_or(status = 'CLOSED') AS is_closed
                        FROM care_interventions
                        WHERE status IN ('PENDING_REVIEW', 'CLOSED')
                        GROUP BY encounter_id
                    )
                    SELECT
                        COUNT(*) AS total_encounters,
                        COUNT(*) FILTER (
                            WHERE pe.risk_level = 'HIGH') AS high_risk,
                        COUNT(*) FILTER (
                            WHERE pe.risk_level = 'MEDIUM') AS medium_risk,
                        COUNT(*) FILTER (WHERE pe.risk_level = 'LOW') AS low_risk,
                        COUNT(*) FILTER (WHERE ci.is_pending) AS pending_interventions,
                        COUNT(*) FILTER (WHERE ci.is_closed) AS closed_interventions
                    FROM patient_encounters pe
                    JOIN ci ON ci.encounter_id = pe.encounter_id;
                """)

                row = cur.fetchone()

                if row is None:
                    raise ValueError("Operations summary not found.")

                columns = [desc[0] for desc in cur.description]
                summary = dict(zip(columns, row))

                return summary

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

