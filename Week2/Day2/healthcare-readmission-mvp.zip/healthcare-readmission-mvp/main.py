from fastapi import FastAPI, HTTPException
import importlib 

app = FastAPI()

#data_loader  = importlib.import_module("data_loader").load_data

#Load csv data into the database
""" @app.post("/loaddata")
def load_data():
    try:
        data_loader()
        return {"message": "Data loaded successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) """

@app.get("/encounters")
def get_encounters():
    # Implementation for fetching encounters
    try:
        services_module = importlib.import_module("services")
        encounters = services_module.get_encounters()   
        return encounters
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/encounters/{encounter_id}")
def get_encounter_by_id(encounter_id: int): 
    try:
        get_encounter_by_id = importlib.import_module("services").get_encounter_by_id
        encounter = get_encounter_by_id(encounter_id)
        return encounter
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/carequeue")
def care_queue():
    try:
        care_queue = importlib.import_module("services").care_queue
        queue = care_queue()
        return queue
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 

@app.get("/carequeue/{risk_level}")
def care_queue_by_risk_level(risk_level: str):
    try:
        care_queue = importlib.import_module("services").care_queue_by_risk_level
        queue = care_queue(risk_level)
        return queue
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.patch("/interventions/{encounter_id}")
def update_interventions_api(encounter_id: int, interventions: dict):
    try:
        update_interventions = importlib.import_module("services").update_interventions
        update_interventions(encounter_id, interventions)
        return {"message": "Interventions updated successfully"}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/operations/summary")
def get_operations_summary():
    try:
        get_operations_summary = importlib.import_module("services").get_operations_summary
        summary = get_operations_summary()
        return summary
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))    

