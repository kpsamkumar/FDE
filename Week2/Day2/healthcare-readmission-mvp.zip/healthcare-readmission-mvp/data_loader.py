import importlib
from pathlib import Path
import csv

from database import get_database_connection

data_file = Path(__file__).parent / "data" / "diabetic_data.csv"

calculate_risk_score = importlib.import_module("services").calculate_risk_score
calculate_risk_level = importlib.import_module("services").calculate_risk_level

# Load the data from the CSV file and insert it into the database
# Calculate the risk score and risk level for each encounter and store them in the database
def load_data():
    with open(data_file, "r") as file:
        reader = csv.DictReader(file)
        with get_database_connection() as conn:
                with conn.cursor() as cur:
                    for row in reader:
                        encounter_id = int(row['encounter_id'].strip())
                        patient_nbr = int(row['patient_nbr'].strip())
                        age = row['age'].strip().removeprefix('[').removesuffix(')')
                        time_in_hospital = int(row['time_in_hospital'].strip())
                        number_inpatient = int(row['number_inpatient'].strip())
                        number_emergency = int(row['number_emergency'].strip())
                        number_outpatient = int(row['number_outpatient'].strip())
                        num_medications = int(row['num_medications'].strip())
                        num_lab_procedures = int(row['num_lab_procedures'].strip())
                        discharge_disposition_id = int(row['discharge_disposition_id'].strip())
                        admission_type_id = int(row['admission_type_id'].strip())
                        readmitted = row['readmitted'].strip()
                        risk_score = calculate_risk_score(number_inpatient, number_emergency, number_outpatient, time_in_hospital, num_medications)
                        print(f"Calculated risk score for encounter_id {encounter_id}: {risk_score}")
                        risk_level = calculate_risk_level(risk_score)
                        print(f"Calculated risk level for encounter_id {encounter_id}: {risk_level}")
                        cur.execute(
                        "INSERT INTO patient_encounters (encounter_id, patient_nbr, age, time_in_hospital, number_inpatient, number_emergency, number_outpatient, num_medications, num_lab_procedures, discharge_disposition_id, admission_type_id, readmitted, risk_score, risk_level) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);",
                        (encounter_id, patient_nbr, age, time_in_hospital, number_inpatient, number_emergency, number_outpatient, num_medications, num_lab_procedures, discharge_disposition_id, admission_type_id, readmitted, risk_score, risk_level)
                    )
                conn.commit()



