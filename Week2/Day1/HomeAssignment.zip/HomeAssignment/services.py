


from fastapi import HTTPException

import importlib


def get_invoices_with_no_amount():
    # Implementation for fetching invoices with no amount
    try:
        repository_module = importlib.import_module("repository")
        invoices = repository_module.get_invoices_with_no_amount()   
        return invoices
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def display_duplicate_invoices():
    # Implementation for removing duplicate invoices when every field is same and it will keep the first invoice and remove the rest
    try:
        repository_module = importlib.import_module("repository")
        unique_invoices = repository_module.display_duplicate_invoices()   
        return unique_invoices
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
def suspected_duplicate_invoices():
    # Implementation for identifying suspected duplicate invoices when all fields are same except invoice_id and it will return the list of suspected duplicate invoices
    try:
        repository_module = importlib.import_module("repository")
        suspected_duplicates = repository_module.suspected_duplicate_invoices()   
        return suspected_duplicates
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def credit_notes():
    # Implementation for identifying credit notes when amount is negative and it will return the list of credit notes
    try:
        repository_module = importlib.import_module("repository")
        credit_notes = repository_module.credit_notes()   
        return credit_notes
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def reconcile_payments():
    # Implementation for reconciling payments with invoices and it will return the list of invoices with their payment status
    try:
        repository_module = importlib.import_module("repository")
        reconciled_invoices = repository_module.reconcile_payments()   
        return reconciled_invoices
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
def normalize_invoices():
    # Implementation for normalizing invoices and it will return the list of normalized invoices
    try:
        repository_module = importlib.import_module("repository")
        normalized_invoices = repository_module.normalize_invoices()   
        return normalized_invoices
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))