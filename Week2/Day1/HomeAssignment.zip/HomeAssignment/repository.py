


import importlib

from fastapi import HTTPException


def load_invoices():
    # Implementation for loading invoices from the JSON file
    with open("data/invoices.json", "r") as file:
        invoices = importlib.import_module("json").load(file)
        return invoices
def load_payments():
    # Implementation for loading payments from the JSON file
    with open("data/payment.json", "r") as file:
        payments = importlib.import_module("json").load(file)
        return payments
    
def get_invoices_with_no_amount():
    # Implementation for fetching invoices with no amount
    try:
        repository_module = importlib.import_module("respository")
        invoices = repository_module.load_invoices()

        no_amount_invoices = [invoice for invoice in invoices if invoice["amount"] == 0]
        return no_amount_invoices
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def display_duplicate_invoices():
    load_invoices = importlib.import_module("repository").load_invoices
    invoices = load_invoices()

    # Implementation for displaying duplicate invoices when every field is same and it will keep the first invoice and remove the rest
    try:
        unique_invoices = []
        seen_invoices = set()

        for invoice in invoices:
            invoice_tuple = tuple(invoice.items())
            if invoice_tuple not in seen_invoices:
                unique_invoices.append(invoice)
                seen_invoices.add(invoice_tuple)

        return unique_invoices
    

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def suspected_duplicate_invoices():
    # Implementation for identifying suspected duplicate invoices when all fields are same except invoice_id and it will return the list of suspected duplicate invoices
    try:

        load_invoices = importlib.import_module("repository").load_invoices
        invoices = load_invoices()
        suspected_duplicates = []
        seen_invoices = {}

        for invoice in invoices:
            key = tuple((k, v) for k, v in invoice.items() if k != "invoice_id")
            if key in seen_invoices:
                suspected_duplicates.append(invoice)
            else:
                seen_invoices[key] = invoice
        #suspected_duplicates = [dict(row) for row in suspected_duplicates]
        return suspected_duplicates
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def credit_notes():
    try:
        seen_invoices = {}
        matched_pairs = []
        matched_indexes = set()
        invoices = load_invoices()

        # First, collect positive invoice indexes
        for index, invoice in enumerate(invoices):
            amount = invoice["amount"]
            vendor = invoice["vendor"].strip().casefold()

            if amount > 0:
                key = (vendor, amount)
                seen_invoices.setdefault(key, []).append(index)

        # Next, find matching negative invoices
        for index, invoice in enumerate(invoices):
            amount = invoice["amount"]
            vendor = invoice["vendor"].strip().casefold()

            if amount < 0:
                key = (vendor, abs(amount))
                partners = seen_invoices.get(key, [])

                # Find an unused positive partner
                positive_index = next(
                    (i for i in partners if i not in matched_indexes),
                    None
                )

                if positive_index is not None:
                    invoice["status"] = "CANCELLED"
                    invoices[positive_index]["status"] = "CANCELLED"

                    matched_indexes.add(index)
                    matched_indexes.add(positive_index)
                    matched_pairs.append((index, positive_index))

                    print(f"{index} <-> {positive_index}")
                else:
                    print(
                        f"Unmatched credit note at index {index}: "
                        f"{amount}"
                    )

        return matched_pairs

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))




def reconcile_payments():
    payment_totals = {}
    results = []

    invoices = load_invoices()
    payments = load_payments()

    # Step 1: Sum payments for each invoice_id
    for payment in payments:
        invoice_id = payment["invoice_id"]
        paid_amount = payment["paid"]

        payment_totals[invoice_id] = (
            payment_totals.get(invoice_id, 0) + paid_amount
        )

    # Step 2: Match payments to invoices
    matched_invoice_ids = set()

    for invoice in invoices:
        invoice_id = invoice["invoice_id"]
        invoice_amount = invoice["amount"]
        total_paid = payment_totals.get(invoice_id, 0)

        matched_invoice_ids.add(invoice_id)

        if invoice_amount is None:
            result = "INVOICE AMOUNT MISSING"
        elif invoice_amount < 0:
            result = "CREDIT NOTE"
        elif total_paid == 0:
            result = "UNPAID"
        elif total_paid < invoice_amount:
            result = "PARTIALLY PAID"
        elif total_paid == invoice_amount:
            result = "FULLY PAID"
        else:
            result = "OVERPAID"

        results.append({
            "invoice_id": invoice_id,
            "invoice_amount": invoice_amount,
            "total_paid": total_paid,
            "reconciliation_status": result
        })

    # Step 3: Find payments without a matching invoice
    for invoice_id, total_paid in payment_totals.items():
        if invoice_id not in matched_invoice_ids:
            results.append({
                "invoice_id": invoice_id,
                "invoice_amount": None,
                "total_paid": total_paid,
                "reconciliation_status": "NO MATCHING INVOICE"
            })

    return results


def normalize_invoices():
    invoices = load_invoices()
    valid_invoices = []
    missing_amount_indexes = []

    for index in range(len(invoices)):
        # Normalize vendor and status in place
        invoices[index]["vendor"] = invoices[index]["vendor"].strip().title()
        invoices[index]["status"] = invoices[index]["status"].upper()

        # Check for missing amount
        if invoices[index]["amount"] is None:
            print(f"Missing amount at index {index}: {invoices[index]}")
            missing_amount_indexes.append(index)
        else:
            valid_invoices.append(invoices[index])

    print("\nNormalized invoices:")
    print(invoices)

    print("\nIndexes with missing amounts:")
    print(missing_amount_indexes)

    # Return only invoices eligible for later totals
    return valid_invoices
