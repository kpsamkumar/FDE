from fastapi import FastAPI, HTTPException  
from services import credit_notes, suspected_duplicate_invoices,display_duplicate_invoices,reconcile_payments

app = FastAPI()

""" @app.get("/invoices/NoAmount")
def get_invoices_with_no_amount():
    return {"message": "Invoices with no amount"} """

@app.get("/invoices/display_duplicates")
def get_remove_duplicate_invoices():
    display_duplicates = display_duplicate_invoices()
    return display_duplicates

@app.get("/invoices/suspected_duplicate_invoices")
def get_suspected_duplicate_invoices():
    suspected_duplicateInvoices = suspected_duplicate_invoices()
    return suspected_duplicateInvoices

@app.get("/invoices/credit_notes")
def get_credit_notes():
    creditNotes = credit_notes()
    return creditNotes  

@app.get("/invoices/reconcile_payments")
def get_reconcile_payments():
    reconciledInvoices = reconcile_payments()
    return reconciledInvoices

@app.get("/invoices/normalize_invoices")
def get_normalize_invoices():
    from services import normalize_invoices
    normalizedInvoices = normalize_invoices()
    return normalizedInvoices
