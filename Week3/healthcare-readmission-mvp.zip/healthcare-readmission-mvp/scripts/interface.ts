export interface encounternew{
encounter_id : number,
patient_nbr : number,
risk_score : number,
risk_level : string,

}

export interface patientSearchDetails{
    patient_nbr:number,
	risk_score:number,
	risk_level:string
}

export interface patientUpdateDetails{
    encounter_id: number,
    status: string,
    assigned_to: string,
    notes: string
}