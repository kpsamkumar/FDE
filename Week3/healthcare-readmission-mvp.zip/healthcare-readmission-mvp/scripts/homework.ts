//import type { encounternew } from "./interface";

import type { encounternew, patientUpdateDetails } from "./interface";
import type { patientSearchDetails } from "./interface";

async function patientsearch(patientSearchDetailsVar: patientSearchDetails) : Promise<patientSearchDetails>{

        const response = await fetch(
        `http://127.0.0.1:8000/patients/search`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(patientSearchDetailsVar)
            
        }
    );

    const data: patientSearchDetails = await response.json();
    console.log(data);
 
    return data;

}

const patientSearchDetailsVar : patientSearchDetails = {
    patient_nbr:8222157,
	risk_score:0,
	risk_level:"LOW"
}

//const result = await patientsearch(patientSearchDetailsVar);
//console.log(result); 


async function searchHighCarePatients(patientSearchDetailsVar: patientSearchDetails) : Promise<patientSearchDetails>{

  
 const response = await fetch(
        `http://127.0.0.1:8000/patients/highcare/search`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(patientSearchDetailsVar)
            
        }
    );

    const data: patientSearchDetails = await response.json();
    console.log(data);
 
    return data;

}   


const patientSearchDetailsVar1 : patientSearchDetails = {
    patient_nbr:null,
	risk_score:null,
	risk_level:"HIGH"
}

 //searchHighCarePatients(patientSearchDetailsVar1);


 
async function update_patient_status(patientUpdate: patientUpdateDetails): Promise<void> {



    const response = await fetch(
        `http://127.0.0.1:8000/patients/statusUpdate`,
        {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(patientUpdate)
        }
    );

    const data = await response.json();

    if (!response.ok) {
        console.error("API Error:", JSON.stringify(data, null, 2));
        return;
    }

    console.log("Updated successfully:", data);
}

const patientUpdateVar : patientUpdateDetails = {
    encounter_id: 149190,
    status: "In Progress",
    assigned_to: "Dr. Smith",
    notes: "Patient requires immediate attention."
};

//update_patient_status(patientUpdateVar)

async function update_patient_status_info (encounter_id: number): Promise<void> {

const response = await fetch(
        `http://127.0.0.1:8000/patients/statusUpdateFetch?encounter_id=${encounter_id}`
       
    );

    const data = await response.json();

    if (!response.ok) {
        console.error("API Error:", JSON.stringify(data, null, 2));
            return;
    }

    console.log("Retrieved successfully:", data);

}
    
update_patient_status_info(149190)


